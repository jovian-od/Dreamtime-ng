export interface DreamLite {
  _id: string;
  description: string;
  username: string;
  tags: string[];
}

